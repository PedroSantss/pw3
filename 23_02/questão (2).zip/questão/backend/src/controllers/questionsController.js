const questions = require('../data/questions');
const template = require('../views/template');

exports.showQuestion = (req, res) => {
    const question = questions[0]; // pega a primeira
    res.send(template.renderQuestion(question));
};

exports.checkAnswer = (req, res) => {
    const userAnswer = req.body.answer;
    const question = questions[0];

    if (userAnswer === question.answer) {
        res.send(template.renderCorrect());
    } else {
        res.send(template.renderWrong(question.solution));
    }
};