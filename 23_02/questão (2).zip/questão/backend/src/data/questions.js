const questions = [
    {
        id: 1,
        question: "Quanto é 5 + 3?",
        answer: "8",
        solution: "5 + 3 = 8. Basta somar os dois números."
    },
    {
        id: 2,
        question: "Quanto é 10 x 2?",
        answer: "20",
        solution: "10 multiplicado por 2 é 20."
    }
];

module.exports = questions;