exports.renderQuestion = (question) => {
    return `
        <html>
        <head>
            <title>Questões de Matemática</title>
        </head>
        <body>
            <h1>${question.question}</h1>

            <form method="POST" action="/answer">
                <input type="text" name="answer" placeholder="Digite sua resposta" required />
                <button type="submit">Responder</button>
            </form>
        </body>
        </html>
    `;
};

exports.renderCorrect = () => {
    return `
        <html>
        <body>
            <h1>✅ Resposta Correta!</h1>
            <a href="/">Voltar</a>
        </body>
        </html>
    `;
};

exports.renderWrong = (solution) => {
    return `
        <html>
        <body>
            <h1>❌ Resposta Errada!</h1>
            <h2>Resolução:</h2>
            <p>${solution}</p>
            <a href="/">Tentar novamente</a>
        </body>
        </html>
    `;
};