const express = require('express');
const bodyParser = require('body-parser');
const questionsRoutes = require('./routes/questions');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', questionsRoutes);

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});