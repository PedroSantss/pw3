const express = require('express');
const router = express.Router();
const controller = require('../controllers/questionsController');

router.get('/', controller.showQuestion);
router.post('/answer', controller.checkAnswer);

module.exports = router;